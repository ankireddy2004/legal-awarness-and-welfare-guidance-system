
export enum AppState {
  IDLE = 'IDLE',
  LISTENING = 'LISTENING',
  PROCESSING = 'PROCESSING',
  SPEAKING = 'SPEAKING',
  PLAYING_VIDEO = 'PLAYING_VIDEO'
}

export interface SchemeData {
  id: string;
  title: string;
  title_hi?: string;
  title_te?: string;
  keywords: string[];
  
  videoId?: string;
  imageUrl?: string;

  audioUrl?: string;
  audioUrl_hi?: string;
  audioUrl_te?: string;
  
  requiredDocuments?: string[];
  applicationSteps?: string[];
  eligibility?: string[];
  benefits?: string[];
  relevantOffice?: string;

  requiredDocuments_hi?: string[];
  applicationSteps_hi?: string[];
  eligibility_hi?: string[];
  benefits_hi?: string[];
  relevantOffice_hi?: string;

  requiredDocuments_te?: string[];
  applicationSteps_te?: string[];
  eligibility_te?: string[];
  benefits_te?: string[];
  relevantOffice_te?: string;
  locationUrl?: string;

  // New fields for Legal Rights
  legalSections?: string[];
  penalties?: string[];

  legalSections_hi?: string[];
  penalties_hi?: string[];

  legalSections_te?: string[];
  penalties_te?: string[];
}

export interface GeminiResponse {
  responseText: string;
  detectedLanguage: 'en-IN' | 'hi-IN' | 'te-IN';
  relevantSchemeId?: string | null;
}

declare global {
  interface Window {
    webkitSpeechRecognition: any;
    SpeechRecognition: any;
  }
}
