
import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

// Declaration to satisfy TypeScript in DOM-target projects when running in Node context
declare const process: any;

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  
  // Flexible key loading to support various naming conventions
  const apiKey = env.VITE_GEMINI_API_KEY || 
                 env.API_KEY || 
                 env.GOOGLE_API_KEY || 
                 process.env.API_KEY || 
                 process.env.VITE_GEMINI_API_KEY ||
                 "";

  return {
    plugins: [react()],
    define: {
      'process.env.API_KEY': JSON.stringify(apiKey),
    },
    server: {
      port: 5173,
      open: true
    }
  };
});
