
import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';

const startApp = () => {
  const rootElement = document.getElementById('root');
  if (!rootElement) {
    console.error("FATAL: Could not find root element 'root' to mount React application.");
    return;
  }

  try {
    const root = createRoot(rootElement);
    root.render(
      <React.StrictMode>
        <App />
      </React.StrictMode>
    );
    console.log("React application mounted successfully.");
  } catch (error: any) {
    console.error("Failed to mount React application:", error);
    rootElement.innerHTML = `
      <div style="color: #ef4444; padding: 20px; font-family: sans-serif; text-align: center;">
        <h2 style="margin-bottom: 10px;">Application Failed to Start</h2>
        <p style="color: #cbd5e1;">${error.message}</p>
        <pre style="background: #1e293b; padding: 10px; border-radius: 8px; margin-top: 20px; text-align: left; overflow: auto;">
          ${error.stack}
        </pre>
      </div>
    `;
  }
};

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', startApp);
} else {
  startApp();
}
