
import React from 'react';
import { AppState } from '../types';

interface MicButtonProps {
  appState: AppState;
  onClick: () => void;
  language: string;
}

const MicButton: React.FC<MicButtonProps> = ({ appState, onClick, language }) => {
  const isListening = appState === AppState.LISTENING;
  const isProcessing = appState === AppState.PROCESSING;
  const isSpeaking = appState === AppState.SPEAKING;

  const getLanguageLabel = (lang: string) => {
    switch (lang) {
      case 'hi-IN': return 'हिन्दी (Hindi)';
      case 'te-IN': return 'తెలుగు (Telugu)';
      default: return 'English (India)';
    }
  };

  const fontClass = language === 'te-IN' ? 'font-telugu' : '';

  const statusLabels = {
    'en-IN': {
      tap: 'Tap to Speak',
      listening: 'Listening...',
      thinking: 'Thinking...',
      speaking: 'Speaking...'
    },
    'hi-IN': {
      tap: 'बोलने के लिए दबाएं',
      listening: 'सुन रहा हूँ...',
      thinking: 'प्रक्रिया चल रही है...',
      speaking: 'बोल रहा हूँ...'
    },
    'te-IN': {
      tap: 'మాట్లాడటానికి నొక్కండి',
      listening: 'వింటున్నాను...',
      thinking: 'ప్రాసెస్ చేస్తోంది...',
      speaking: 'మాట్లాడుతున్నాను...'
    }
  };

  const currentLabels = statusLabels[language as keyof typeof statusLabels] || statusLabels['en-IN'];

  const getStatusText = () => {
    if (isListening) return currentLabels.listening;
    if (isProcessing) return currentLabels.thinking;
    if (isSpeaking) return currentLabels.speaking;
    return currentLabels.tap;
  };

  return (
    <div className="relative group flex flex-col items-center">
      {isListening && (
        <>
          <div className="absolute inset-0 bg-red-500 rounded-full opacity-20 animate-ping"></div>
          <div className="absolute -inset-4 bg-red-500 rounded-full opacity-10 animate-pulse delay-75"></div>
          <div className="absolute -inset-8 bg-red-500 rounded-full opacity-5 animate-pulse delay-150"></div>
        </>
      )}

      {isSpeaking && (
        <>
          <div className="absolute inset-0 bg-green-500 rounded-full opacity-20 animate-ping duration-[3000ms]"></div>
          <div className="absolute -inset-4 bg-green-500 rounded-full opacity-10 animate-pulse"></div>
        </>
      )}

      <button
        onClick={onClick}
        disabled={isProcessing || isSpeaking}
        className={`
          relative z-10 flex items-center justify-center
          w-32 h-32 md:w-40 md:h-40 rounded-full
          transition-all duration-300 transform hover:scale-105 active:scale-95
          shadow-[0_0_50px_rgba(0,0,0,0.6)]
          border-4 
          ${isListening ? 'bg-red-600 border-red-400' : 
            isProcessing ? 'bg-amber-500 border-amber-300' :
            isSpeaking ? 'bg-green-600 border-green-400' :
            'bg-blue-600 border-blue-400 hover:bg-blue-500 shadow-blue-500/20'}
        `}
      >
        {isProcessing ? (
          <svg className="animate-spin h-12 w-12 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
        ) : (
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            className={`h-16 w-16 text-white transition-transform ${isListening ? 'scale-110' : ''}`}
            fill="none" 
            viewBox="0 0 24 24" 
            stroke="currentColor"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
          </svg>
        )}
      </button>
      
      <div className="mt-8 text-center">
        <p className={`text-xl md:text-2xl font-black tracking-widest uppercase text-white drop-shadow-lg ${fontClass}`}>
          {getStatusText()}
        </p>
        
        <div className={`mt-3 inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-slate-800/80 border border-slate-700/50 shadow-lg backdrop-blur-md ${fontClass}`}>
          <div className={`w-2 h-2 rounded-full ${isListening ? 'bg-red-500 animate-pulse' : 'bg-blue-500'}`}></div>
          <span className="text-[10px] md:text-xs font-bold uppercase tracking-[0.15em] text-blue-300/90">
            Active: {getLanguageLabel(language)}
          </span>
        </div>
      </div>
    </div>
  );
};

export default MicButton;
