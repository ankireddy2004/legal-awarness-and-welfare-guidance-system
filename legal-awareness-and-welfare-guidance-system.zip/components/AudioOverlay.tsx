
import React, { useEffect, useState, useRef } from 'react';
import { SchemeData } from '../types';

interface AudioOverlayProps {
  scheme: SchemeData | null;
  onClose: () => void;
  language: string; 
  onSwitchToVideo: () => void;
  onNarrate?: (text: string) => void;
}

const AudioOverlay: React.FC<AudioOverlayProps> = ({ scheme, onClose, language, onSwitchToVideo, onNarrate }) => {
  const [visible, setVisible] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (scheme) {
      setVisible(true);
      setIsPlaying(false);
      setProgress(0);
    } else {
      setVisible(false);
      setIsPlaying(false);
      if (audioRef.current) audioRef.current.pause();
    }
  }, [scheme]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const updateProgress = () => setProgress((audio.currentTime / audio.duration) * 100);
    const onLoadedMetadata = () => setDuration(audio.duration);
    const onEnded = () => { setIsPlaying(false); setProgress(0); };

    audio.addEventListener('timeupdate', updateProgress);
    audio.addEventListener('loadedmetadata', onLoadedMetadata);
    audio.addEventListener('ended', onEnded);

    return () => {
      audio.removeEventListener('timeupdate', updateProgress);
      audio.removeEventListener('loadedmetadata', onLoadedMetadata);
      audio.removeEventListener('ended', onEnded);
    };
  }, [scheme, language]);

  if (!visible || !scheme) return null;

  let title = scheme.title;
  let docs = scheme.requiredDocuments;
  let steps = scheme.applicationSteps;
  let eligibility = scheme.eligibility;
  let benefits = scheme.benefits;
  let audioSrc = scheme.audioUrl;
  
  if (language === 'hi-IN') {
    title = scheme.title_hi || title;
    docs = scheme.requiredDocuments_hi || docs;
    steps = scheme.applicationSteps_hi || steps;
    eligibility = scheme.eligibility_hi || eligibility;
    benefits = scheme.benefits_hi || benefits;
    audioSrc = scheme.audioUrl_hi || audioSrc;
  } else if (language === 'te-IN') {
    title = scheme.title_te || title;
    docs = scheme.requiredDocuments_te || docs;
    steps = scheme.applicationSteps_te || steps;
    eligibility = scheme.eligibility_te || eligibility;
    benefits = scheme.benefits_te || benefits;
    audioSrc = scheme.audioUrl_te || audioSrc;
  }

  const labels = {
    'en-IN': { docs: 'Required Documents', steps: 'Application Steps', benefits: 'Benefits', eligibility: 'Eligibility', close: 'Close', step: 'Step', title: 'Audio Briefing', videoBtn: 'Switch to Video', locateMeeSeva: 'Locate Nearest MeeSeva', locatePolice: 'Locate Police Station', mapBtn: 'Open Maps', listen: 'Listen' },
    'hi-IN': { docs: 'आवश्यक दस्तावेज', steps: 'आवेदन के चरण', benefits: 'लाभ', eligibility: 'पात्रता', close: 'बंद करें', step: 'चरण', title: 'ऑडियो जानकारी', videoBtn: 'वीडियो गाइड', locateMeeSeva: 'नज़दीकी मी-सेवा खोजें', locatePolice: 'पुलिस स्टेशन खोजें', mapBtn: 'मैप्स', listen: 'सुनें' },
    'te-IN': { docs: 'అవసరమైన పత్రాలు', steps: 'దరఖాస్తు విధానం', benefits: 'ప్రయోజనాలు', eligibility: 'అర్హత', close: 'ముగించు', step: 'దశ', title: 'ఆడియో సమాచారం', videoBtn: 'వీడియో గైడ్', locateMeeSeva: 'మీసేవా కేంద్రాన్ని చూపించు', locatePolice: 'పోలీస్ స్టేషన్ చూపించు', mapBtn: 'మ్యాప్స్', listen: 'వినండి' }
  };
  
  const currentLabels = labels[language as keyof typeof labels] || labels['en-IN'];
  const isPolice = scheme.locationUrl?.includes('Police');
  const locateLabel = isPolice ? currentLabels.locatePolice : currentLabels.locateMeeSeva;
  const fontClass = language === 'te-IN' ? 'font-telugu' : '';

  const handleNarrate = (title: string, items: string[]) => {
    if (onNarrate) {
      const text = `${title}. ${items.join('. ')}`;
      onNarrate(text);
    }
  };

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) audioRef.current.pause();
    else audioRef.current.play();
    setIsPlaying(!isPlaying);
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    if (audioRef.current) {
      audioRef.current.currentTime = (val / 100) * audioRef.current.duration;
      setProgress(val);
    }
  };

  const formatTime = (time: number) => {
    if (isNaN(time)) return "0:00";
    const mins = Math.floor(time / 60);
    const secs = Math.floor(time % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className={`fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/95 backdrop-blur-xl animate-in fade-in zoom-in duration-300 ${fontClass}`}>
      <div className="w-full max-w-6xl bg-slate-900 rounded-[40px] overflow-hidden border border-slate-700 shadow-[0_0_100px_rgba(37,99,235,0.2)] flex flex-col max-h-[90vh]">
        
        <div className="flex items-center justify-between p-6 border-b border-slate-800 bg-slate-900/50">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-4">
              <div className="w-3 h-12 bg-blue-500 rounded-full shadow-[0_0_15px_rgba(59,130,246,0.5)]"></div>
              <div>
                <h2 className="text-3xl font-black text-white">{title}</h2>
                <p className="text-xs text-blue-400 font-bold uppercase tracking-widest mt-1">{currentLabels.title}</p>
              </div>
            </div>
            
            <button 
              onClick={onSwitchToVideo}
              className="px-4 py-2 bg-slate-800 hover:bg-red-600 rounded-xl text-slate-400 hover:text-white transition-all border border-slate-700 flex items-center gap-2 text-xs font-black uppercase tracking-widest"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
              {currentLabels.videoBtn}
            </button>
          </div>
          
          <button onClick={onClose} className="p-3 bg-slate-800 hover:bg-red-600 rounded-2xl text-slate-400 hover:text-white transition-all border border-slate-700">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar p-8 space-y-12">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
            <div className="lg:col-span-7 space-y-10">
              <div className="bg-gradient-to-br from-slate-800 to-slate-900 p-8 rounded-[40px] border border-blue-500/20 shadow-2xl flex flex-col items-center">
                <div className="relative mb-10">
                   <div className={`w-32 h-32 rounded-full bg-blue-500/10 flex items-center justify-center border-2 border-blue-500/30 ${isPlaying ? 'animate-pulse' : ''}`}>
                      <div className={`w-20 h-20 rounded-full bg-blue-500/20 flex items-center justify-center border border-blue-400/30 ${isPlaying ? 'scale-110' : 'scale-100'} transition-transform duration-500`}>
                         <svg className={`w-10 h-10 ${isPlaying ? 'text-blue-400' : 'text-slate-500'}`} fill="currentColor" viewBox="0 0 24 24"><path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/></svg>
                      </div>
                   </div>
                </div>
                <div className="w-full space-y-6">
                  <div className="flex items-center justify-center gap-6">
                    <button onClick={togglePlay} className="w-20 h-20 bg-blue-600 hover:bg-blue-500 rounded-full flex items-center justify-center shadow-blue-600/20 shadow-2xl transform active:scale-95 transition-all text-white border-4 border-blue-400/20">
                      {isPlaying ? <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg> : <svg className="w-8 h-8 ml-1" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>}
                    </button>
                  </div>
                  <div className="w-full px-4">
                    <input type="range" min="0" max="100" value={progress} onChange={handleSeek} className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500" />
                    <div className="flex justify-between text-[10px] font-black text-slate-500 uppercase tracking-widest mt-2">
                      <span>{formatTime(audioRef.current?.currentTime || 0)}</span>
                      <span>{formatTime(duration)}</span>
                    </div>
                  </div>
                </div>
                <audio ref={audioRef} src={audioSrc} preload="metadata" />
              </div>
              
              {steps && (
                <div className="bg-slate-800/40 p-8 rounded-[40px] border border-slate-800">
                  <div className="flex items-center justify-between mb-10">
                    <h3 className="text-xl font-black text-blue-400 flex items-center gap-3 uppercase tracking-tighter">{currentLabels.steps}</h3>
                    <button 
                      onClick={() => handleNarrate(currentLabels.steps, steps)}
                      className="p-2 bg-blue-500/20 hover:bg-blue-500/40 rounded-xl text-blue-400 transition-all flex items-center gap-2 text-[10px] font-black uppercase tracking-widest"
                    >
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 5.000 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" /></svg>
                      {currentLabels.listen}
                    </button>
                  </div>
                  <div className="relative pl-6">
                    <div className="absolute left-[39px] top-6 bottom-12 w-1 bg-gradient-to-b from-blue-600 to-transparent"></div>
                    <div className="space-y-10">
                      {steps.map((step, idx) => {
                        const isMeeSeva = /meeseva|మీసేవా|మీ-సేవా|मी-सेवा/i.test(step);
                        return (
                          <div key={idx} className="relative flex gap-8 group">
                            <div className="w-16 h-16 rounded-2xl bg-slate-900 border-4 border-blue-600 flex items-center justify-center shadow-lg group-hover:bg-blue-600 group-hover:border-blue-400 shrink-0 z-10">
                              <span className="text-white font-black text-xl">{idx + 1}</span>
                            </div>
                            <div className="flex-1 bg-slate-800/50 p-6 rounded-3xl border border-slate-700/50 group-hover:border-blue-500/50 transition-all">
                              <h4 className="text-[10px] font-black text-blue-500 uppercase tracking-widest mb-2">{currentLabels.step} {idx + 1}</h4>
                              <p className="text-slate-200 text-lg font-medium leading-relaxed">{step}</p>
                              {isMeeSeva && (
                                <div className="mt-4">
                                  <a 
                                    href={scheme.locationUrl || "https://www.google.com/maps/search/MeeSeva+Center+near+me"} 
                                    target="_blank" 
                                    rel="noopener noreferrer"
                                    className={`inline-flex items-center gap-2 px-4 py-2 ${isPolice ? 'bg-red-600 hover:bg-red-500 shadow-red-900/20' : 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-900/20'} border border-white/20 rounded-xl text-white transition-all duration-300 shadow-lg group/btn`}
                                  >
                                    <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                                    </svg>
                                    <span className="text-xs font-bold uppercase tracking-wider">{locateLabel}</span>
                                  </a>
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            <div className="lg:col-span-5 space-y-8">
              {benefits && (
                <div className="bg-gradient-to-br from-emerald-950/20 to-slate-900 p-8 rounded-[40px] border border-emerald-500/20">
                  <div className="flex items-center justify-between mb-6">
                    <h4 className="text-emerald-400 font-black flex items-center gap-3 uppercase text-sm tracking-widest">{currentLabels.benefits}</h4>
                    <button 
                      onClick={() => handleNarrate(currentLabels.benefits, benefits)}
                      className="p-2 bg-emerald-500/20 hover:bg-emerald-500/40 rounded-xl text-emerald-400 transition-all flex items-center gap-2 text-[10px] font-black uppercase tracking-widest"
                    >
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" /></svg>
                      {currentLabels.listen}
                    </button>
                  </div>
                  <ul className="space-y-4">{benefits.map((b, i) => <li key={i} className="text-slate-300 flex items-start gap-3 text-base leading-relaxed"><div className="w-2 h-2 bg-emerald-500 rounded-full mt-2 shrink-0"></div>{b}</li>)}</ul>
                </div>
              )}
              {eligibility && (
                <div className="bg-amber-950/20 p-8 rounded-[40px] border border-amber-500/20">
                  <div className="flex items-center justify-between mb-6">
                    <h4 className="text-amber-400 font-black flex items-center gap-3 uppercase text-sm tracking-widest">{currentLabels.eligibility}</h4>
                    <button 
                      onClick={() => handleNarrate(currentLabels.eligibility, eligibility)}
                      className="p-2 bg-amber-500/20 hover:bg-amber-500/40 rounded-xl text-amber-400 transition-all flex items-center gap-2 text-[10px] font-black uppercase tracking-widest"
                    >
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" /></svg>
                      {currentLabels.listen}
                    </button>
                  </div>
                  <ul className="space-y-4">{eligibility.map((e, i) => <li key={i} className="text-slate-300 flex items-start gap-3 text-base leading-relaxed"><div className="w-2 h-2 bg-amber-500 rounded-full mt-2 shrink-0"></div>{e}</li>)}</ul>
              </div>
              )}
              {docs && (
                <div className="bg-blue-950/20 p-8 rounded-[40px] border border-blue-500/20">
                  <div className="flex items-center justify-between mb-6">
                    <h4 className="text-blue-400 font-black flex items-center gap-3 uppercase text-sm tracking-widest">{currentLabels.docs}</h4>
                    <button 
                      onClick={() => handleNarrate(currentLabels.docs, docs)}
                      className="p-2 bg-blue-500/20 hover:bg-blue-500/40 rounded-xl text-blue-400 transition-all flex items-center gap-2 text-[10px] font-black uppercase tracking-widest"
                    >
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" /></svg>
                      {currentLabels.listen}
                    </button>
                  </div>
                  <div className="grid grid-cols-1 gap-4">{docs.map((doc, i) => <div key={i} className="flex items-center gap-4 bg-slate-800/60 p-4 rounded-2xl border border-slate-700/50"><svg className="w-5 h-5 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" /></svg><span className="text-slate-200 font-bold text-sm">{doc}</span></div>)}</div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AudioOverlay;
