
import React, { useEffect, useState } from 'react';
import { SchemeData } from '../types';

interface VideoOverlayProps {
  scheme: SchemeData | null;
  onClose: () => void;
  language: string; 
  onSwitchToAudio: () => void;
  onNarrate?: (text: string) => void;
}

const VideoOverlay: React.FC<VideoOverlayProps> = ({ scheme, onClose, language, onSwitchToAudio, onNarrate }) => {
  const [visible, setVisible] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
    if (scheme) { setVisible(true); setIsPlaying(false); } 
    else { setVisible(false); setIsPlaying(false); }
  }, [scheme]);

  if (!visible || !scheme) return null;

  let title = scheme.title;
  let docs = scheme.requiredDocuments;
  let steps = scheme.applicationSteps;
  let eligibility = scheme.eligibility;
  let benefits = scheme.benefits;
  let office = scheme.relevantOffice;
  let sections = scheme.legalSections;
  let penalties = scheme.penalties;

  if (language === 'hi-IN') {
    title = scheme.title_hi || title;
    docs = scheme.requiredDocuments_hi || docs;
    steps = scheme.applicationSteps_hi || steps;
    eligibility = scheme.eligibility_hi || eligibility;
    benefits = scheme.benefits_hi || benefits;
    office = scheme.relevantOffice_hi || office;
    sections = scheme.legalSections_hi || sections;
    penalties = scheme.penalties_hi || penalties;
  } else if (language === 'te-IN') {
    title = scheme.title_te || title;
    docs = scheme.requiredDocuments_te || docs;
    steps = scheme.applicationSteps_te || steps;
    eligibility = scheme.eligibility_te || eligibility;
    benefits = scheme.benefits_te || benefits;
    office = scheme.relevantOffice_te || office;
    sections = scheme.legalSections_te || sections;
    penalties = scheme.penalties_te || penalties;
  }

  const labels = {
    'en-IN': { docs: 'Required Documents', steps: 'How to Apply', benefits: 'Benefits', eligibility: 'Eligibility', office: 'Relevant Office', close: 'Close', step: 'Step', locateMeeSeva: 'Locate Nearest MeeSeva', locatePolice: 'Locate Police Station', mapBtn: 'Open in Maps', sec: 'Legal Sections', pen: 'Penalties & Fines', listen: 'Listen' },
    'hi-IN': { docs: 'आवश्यक दस्तावेज', steps: 'आवेदन कैसे करें', benefits: 'लाभ', eligibility: 'पात्रता', office: 'संबंधित कार्यालय', close: 'बंद करें', step: 'चरण', locateMeeSeva: 'नज़दीकी मी-सेवा खोजें', locatePolice: 'पुलिस स्टेशन खोजें', mapBtn: 'मैप्स खोलें', sec: 'कानूनी धाराएं', pen: 'जुर्माना और दंड', listen: 'सुनें' },
    'te-IN': { docs: 'అవసరమైన పత్రాలు', steps: 'ఎలా దరఖాస్తు చేయాలి', benefits: 'ప్రయోజనాలు', eligibility: 'అర్హత', office: 'సంబంధిత కార్యాలయం', close: 'మూసివేయండి', step: 'దశ', locateMeeSeva: 'మీసేవా కేంద్రాన్ని చూపించు', locatePolice: 'పోలీస్ స్టేషన్ చూపించు', mapBtn: 'మ్యాప్స్ లో చూడండి', sec: 'చట్టపరమైన సెక్షన్లు', pen: 'శిక్షలు మరియు జరిమానాలు', listen: 'వినండి' }
  };
  
  const currentLabels = labels[language as keyof typeof labels] || labels['en-IN'];
  const isPolice = scheme.locationUrl?.includes('Police');
  const locateLabel = isPolice ? currentLabels.locatePolice : currentLabels.locateMeeSeva;
  const fontClass = language === 'te-IN' ? 'font-telugu' : '';

  const handleNarrate = (title: string, items: string[]) => {
    if (onNarrate) {
      const text = `${title}. ${items.join('. ')}`;
      onNarrate(text);
    }
  };

  return (
    <div className={`fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/95 backdrop-blur-xl animate-in fade-in duration-300 ${fontClass}`}>
      <div className="w-full max-w-6xl bg-slate-900 rounded-[40px] overflow-hidden border border-slate-700 shadow-[0_0_100px_rgba(37,99,235,0.2)] flex flex-col max-h-[95vh]">
        
        <div className="flex items-center justify-between p-6 border-b border-slate-800 bg-slate-900/80 sticky top-0 z-10">
          <div className="flex items-center gap-6">
            <h2 className="text-3xl font-black text-white flex items-center gap-4">
              <span className="w-2.5 h-12 bg-blue-500 rounded-full shadow-[0_0_15px_rgba(59,130,246,0.5)]"></span>
              {title}
            </h2>
          </div>
          <button onClick={onClose} className="group p-3 bg-slate-800 hover:bg-red-600 rounded-2xl text-slate-400 hover:text-white transition-all border border-slate-700">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 group-hover:rotate-90 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar p-8 space-y-12">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
            <div className="lg:col-span-7 space-y-10">
              {scheme.imageUrl && (
                <div className="rounded-[32px] overflow-hidden bg-slate-950 shadow-2xl aspect-video border border-slate-800 relative group flex items-center justify-center">
                   <img src={scheme.imageUrl} alt={title} className="w-full h-full object-cover" />
                   <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent"></div>
                </div>
              )}

              {/* LEGAL SECTIONS & PENALTIES BLOCK (Prominent for Legal Schemes) */}
              {(sections || penalties) && (
                <div className="bg-red-950/30 p-8 rounded-[40px] border border-red-500/30 relative overflow-hidden">
                   <div className="absolute top-0 right-0 w-32 h-32 bg-red-500/10 rounded-bl-[100px] pointer-events-none"></div>
                   
                   {sections && sections.length > 0 && (
                     <div className="mb-8">
                       <div className="flex items-center justify-between mb-6">
                         <h3 className="text-xl font-black text-red-400 flex items-center gap-3 uppercase tracking-tighter">
                           <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" /></svg>
                           {currentLabels.sec}
                         </h3>
                         <button 
                           onClick={() => handleNarrate(currentLabels.sec, sections)}
                           className="p-2 bg-red-500/20 hover:bg-red-500/40 rounded-xl text-red-400 transition-all flex items-center gap-2 text-[10px] font-black uppercase tracking-widest"
                         >
                           <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 5.000 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" /></svg>
                           {currentLabels.listen}
                         </button>
                       </div>
                       <ul className="space-y-4">
                         {sections.map((sec, i) => (
                           <li key={i} className="flex gap-4 p-4 bg-red-900/20 rounded-2xl border border-red-500/20 items-center">
                             <div className="w-2 h-2 bg-red-500 rounded-full shrink-0"></div>
                             <span className="text-slate-200 font-bold text-lg">{sec}</span>
                           </li>
                         ))}
                       </ul>
                     </div>
                   )}

                   {penalties && penalties.length > 0 && (
                     <div>
                       <div className="flex items-center justify-between mb-6">
                         <h3 className="text-xl font-black text-orange-400 flex items-center gap-3 uppercase tracking-tighter">
                           <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                           {currentLabels.pen}
                         </h3>
                         <button 
                           onClick={() => handleNarrate(currentLabels.pen, penalties)}
                           className="p-2 bg-orange-500/20 hover:bg-orange-500/40 rounded-xl text-orange-400 transition-all flex items-center gap-2 text-[10px] font-black uppercase tracking-widest"
                         >
                           <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 5.000 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" /></svg>
                           {currentLabels.listen}
                         </button>
                       </div>
                       <ul className="space-y-4">
                         {penalties.map((pen, i) => (
                           <li key={i} className="flex gap-4 p-4 bg-orange-900/20 rounded-2xl border border-orange-500/20 items-center">
                             <span className="text-orange-200 font-medium text-lg leading-relaxed">{pen}</span>
                           </li>
                         ))}
                       </ul>
                     </div>
                   )}
                </div>
              )}

              {steps && (
                <div className="bg-slate-800/40 p-8 rounded-[40px] border border-slate-800">
                  <div className="flex items-center justify-between mb-10">
                    <h3 className="text-xl font-black text-blue-400 flex items-center gap-3 uppercase tracking-tighter">
                      {currentLabels.steps}
                    </h3>
                    <button 
                      onClick={() => handleNarrate(currentLabels.steps, steps)}
                      className="p-2 bg-blue-500/20 hover:bg-blue-500/40 rounded-xl text-blue-400 transition-all flex items-center gap-2 text-[10px] font-black uppercase tracking-widest"
                    >
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 5.000 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" /></svg>
                      {currentLabels.listen}
                    </button>
                  </div>
                  <div className="relative pl-6">
                    <div className="absolute left-[39px] top-6 bottom-12 w-1 bg-gradient-to-b from-blue-600 to-transparent"></div>
                    <div className="space-y-10">
                      {steps.map((step, idx) => {
                         const isMeeSeva = /meeseva|మీసేవా|మీ-సేవా|मी-सेवा/i.test(step);
                         return (
                          <div key={idx} className="relative flex gap-8 group">
                            <div className="w-16 h-16 rounded-2xl bg-slate-900 border-4 border-blue-600 flex items-center justify-center shadow-lg group-hover:bg-blue-600 group-hover:border-blue-400 shrink-0 z-10 transition-all">
                              <span className="text-white font-black text-xl">{idx + 1}</span>
                            </div>
                            <div className="flex-1 bg-slate-800/50 p-6 rounded-3xl border border-slate-700/50 group-hover:border-blue-500/50 transition-all">
                              <p className="text-slate-200 text-lg font-medium leading-relaxed">{step}</p>
                              {isMeeSeva && (
                                <div className="mt-4">
                                  <a 
                                    href={scheme.locationUrl || "https://www.google.com/maps/search/MeeSeva+Center+near+me"} 
                                    target="_blank" 
                                    rel="noopener noreferrer"
                                    className={`inline-flex items-center gap-2 px-4 py-2 ${isPolice ? 'bg-red-600 hover:bg-red-500 shadow-red-900/20' : 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-900/20'} border border-white/20 rounded-xl text-white transition-all duration-300 shadow-lg group/btn`}
                                  >
                                    <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                                    </svg>
                                    <span className="text-xs font-bold uppercase tracking-wider">{locateLabel}</span>
                                  </a>
                                </div>
                              )}
                            </div>
                          </div>
                         );
                      })}
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="lg:col-span-5 space-y-8">
              {office && (
                <div className="bg-blue-600/10 p-8 rounded-[40px] border border-blue-500/30">
                  <h4 className="text-blue-400 font-black flex items-center gap-3 mb-4 uppercase text-xs tracking-widest">
                    {currentLabels.office}
                  </h4>
                  <div className="flex items-center gap-4 bg-slate-900/60 p-5 rounded-2xl border border-blue-500/20">
                    <div className="bg-blue-500/20 p-3 rounded-xl">
                      <svg className="w-6 h-6 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>
                    </div>
                    <span className="text-blue-100 font-black text-lg">{office}</span>
                  </div>
                </div>
              )}

              {benefits && (
                <div className="bg-emerald-950/20 p-8 rounded-[40px] border border-emerald-500/20">
                  <div className="flex items-center justify-between mb-6">
                    <h4 className="text-emerald-400 font-black flex items-center gap-3 uppercase text-sm tracking-widest">{currentLabels.benefits}</h4>
                    <button 
                      onClick={() => handleNarrate(currentLabels.benefits, benefits)}
                      className="p-2 bg-emerald-500/20 hover:bg-emerald-500/40 rounded-xl text-emerald-400 transition-all flex items-center gap-2 text-[10px] font-black uppercase tracking-widest"
                    >
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" /></svg>
                      {currentLabels.listen}
                    </button>
                  </div>
                  <ul className="space-y-4">{benefits.map((b, i) => <li key={i} className="text-slate-300 flex items-start gap-3 text-base leading-relaxed"><div className="w-2 h-2 bg-emerald-500 rounded-full mt-2 shrink-0"></div>{b}</li>)}</ul>
                </div>
              )}

              {eligibility && (
                <div className="bg-amber-950/20 p-8 rounded-[40px] border border-amber-500/20">
                  <div className="flex items-center justify-between mb-6">
                    <h4 className="text-amber-400 font-black flex items-center gap-3 uppercase text-sm tracking-widest">{currentLabels.eligibility}</h4>
                    <button 
                      onClick={() => handleNarrate(currentLabels.eligibility, eligibility)}
                      className="p-2 bg-amber-500/20 hover:bg-amber-500/40 rounded-xl text-amber-400 transition-all flex items-center gap-2 text-[10px] font-black uppercase tracking-widest"
                    >
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" /></svg>
                      {currentLabels.listen}
                    </button>
                  </div>
                  <ul className="space-y-4">{eligibility.map((e, i) => <li key={i} className="text-slate-300 flex items-start gap-3 text-base leading-relaxed"><div className="w-2 h-2 bg-amber-500 rounded-full mt-2 shrink-0"></div>{e}</li>)}</ul>
                </div>
              )}

              {docs && (
                <div className="bg-slate-800/60 p-8 rounded-[40px] border border-slate-700">
                  <div className="flex items-center justify-between mb-6">
                    <h4 className="text-slate-400 font-black flex items-center gap-3 uppercase text-sm tracking-widest">{currentLabels.docs}</h4>
                    <button 
                      onClick={() => handleNarrate(currentLabels.docs, docs)}
                      className="p-2 bg-slate-700 hover:bg-slate-600 rounded-xl text-slate-300 transition-all flex items-center gap-2 text-[10px] font-black uppercase tracking-widest"
                    >
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" /></svg>
                      {currentLabels.listen}
                    </button>
                  </div>
                  <div className="grid grid-cols-1 gap-4">
                    {docs.map((doc, i) => (
                      <div key={i} className="flex items-center gap-4 bg-slate-900/60 p-4 rounded-2xl border border-slate-700/50">
                        <svg className="w-5 h-5 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" /></svg>
                        <span className="text-slate-200 font-bold text-sm">{doc}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoOverlay;
