
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { SYSTEM_INSTRUCTION, SCHEMES } from '../constants';
import { GeminiResponse } from '../types';

declare const process: any;

/**
 * OFFLINE FALLBACK ENGINE
 * Analyzes text locally to find matching schemes when API is unavailable.
 */
const getOfflineFallback = (text: string): GeminiResponse => {
  const lowerText = (text || "").toLowerCase();
  
  // 1. Intelligent Keyword Matching
  // Checks scheme titles, translated titles, and specific keywords in the database
  const matchedScheme = SCHEMES.find(scheme => 
    scheme.keywords.some(keyword => lowerText.includes(keyword.toLowerCase())) ||
    scheme.title.toLowerCase().includes(lowerText) ||
    (scheme.title_te && scheme.title_te.includes(text)) ||
    (scheme.title_hi && scheme.title_hi.includes(text))
  );

  // 2. Language Detection based on script
  let detectedLang: 'en-IN' | 'te-IN' | 'hi-IN' = 'en-IN';
  if (/[\u0C00-\u0C7F]/.test(text)) detectedLang = 'te-IN';
  else if (/[\u0900-\u097F]/.test(text)) detectedLang = 'hi-IN';

  // 3. Construct a Success Response
  if (matchedScheme) {
    const responses = {
      'en-IN': `I have found the details for ${matchedScheme.title}. Here is the information.`,
      'hi-IN': `मुझे ${matchedScheme.title_hi || matchedScheme.title} के विवरण मिले हैं।`,
      'te-IN': `${matchedScheme.title_te || matchedScheme.title} వివరాలు ఇక్కడ ఉన్నాయి.`
    };
    return {
      responseText: responses[detectedLang],
      detectedLanguage: detectedLang,
      relevantSchemeId: matchedScheme.id
    };
  }

  // 4. Default Prompt (if no keyword matched)
  const defaultResponses = {
    'en-IN': "I am listening. Ask me about Ration Card, Rythu Bandhu, or Pensions.",
    'hi-IN': "मैं सुन रहा हूँ। राशन कार्ड या पेंशन के बारे में पूछें।",
    'te-IN': "నేను వింటున్నాను. రేషన్ కార్డు లేదా పెన్షన్ గురించి అడగండి."
  };

  return {
    responseText: defaultResponses[detectedLang],
    detectedLanguage: detectedLang,
    relevantSchemeId: null
  };
};

export const processUserQuery = async (transcript?: string, audioBase64?: string): Promise<GeminiResponse> => {
  
  // --- STEP 1: GET API KEY ---
  // Try multiple sources for the key to be safe
  let apiKey = process.env.API_KEY;
  if (!apiKey || apiKey.includes("PASTE")) {
    apiKey = (import.meta as any).env.VITE_GEMINI_API_KEY;
  }
  if (apiKey) apiKey = apiKey.trim().replace(/^"|"$/g, '');
  
  const isKeyInvalid = !apiKey || apiKey.length < 10 || apiKey.includes("PASTE");

  // --- STEP 2: CHECK CONDITION ---
  // If key is missing, immediately use Safe Mode (Local Logic)
  if (isKeyInvalid) {
    console.warn("⚠️ Demo Mode: Using local logic (API Key missing)");
    return getOfflineFallback(transcript || "");
  }

  // --- STEP 3: ATTEMPT AI REQUEST ---
  try {
    const ai = new GoogleGenAI({ apiKey });
    // Use Gemini 3 Flash Preview
    const modelsToTry = ['gemini-3-flash-preview', 'gemini-3.1-pro-preview'];

    const simplifiedSchemes = SCHEMES.map(s => ({
      id: s.id, title: s.title, title_te: s.title_te, keywords: s.keywords
    }));

    // Recursive retry logic
    const makeRequest = async (modelIndex = 0): Promise<GenerateContentResponse> => {
      if (modelIndex >= modelsToTry.length) throw new Error("Models exhausted");

      const currentModel = modelsToTry[modelIndex];
      let contents: any;

      if (audioBase64) {
        contents = {
          parts: [
            { inlineData: { mimeType: "audio/webm", data: audioBase64 } },
            { text: `Identify government scheme. Database: ${JSON.stringify(simplifiedSchemes)}` }
          ]
        };
      } else {
        contents = { parts: [{ text: `Database: ${JSON.stringify(simplifiedSchemes)}\nQuery: "${transcript}"` }] };
      }

      try {
        return await ai.models.generateContent({
          model: currentModel,
          contents: contents,
          config: {
            systemInstruction: SYSTEM_INSTRUCTION,
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                responseText: { type: Type.STRING },
                detectedLanguage: { type: Type.STRING },
                relevantSchemeId: { type: Type.STRING },
              },
              required: ['responseText', 'detectedLanguage']
            }
          }
        });
      } catch (e) {
        return makeRequest(modelIndex + 1);
      }
    };

    const response = await makeRequest();
    const text = response.text;
    if (!text) throw new Error("Empty response");
    return JSON.parse(text);

  } catch (error) {
    console.error("Online Service Unavailable. Switching to Safe Mode.", error);
    
    // --- STEP 4: SEAMLESS FALLBACK ---
    // If the API fails (Network, Date Error, Quota), we silently switch to 
    // the local Safe Mode logic so the user doesn't see an error screen.
    if (transcript && transcript.length > 0) {
      return getOfflineFallback(transcript);
    }

    return {
      responseText: "I'm ready. Please say the scheme name clearly.",
      detectedLanguage: 'en-IN',
      relevantSchemeId: null
    };
  }
};
