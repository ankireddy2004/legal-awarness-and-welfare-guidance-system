
import React, { useState, useEffect, useCallback, useRef } from 'react';
import MicButton from './components/MicButton';
import VideoOverlay from './components/VideoOverlay';
import AudioOverlay from './components/AudioOverlay';
import { AppState, SchemeData } from './types';
import { APP_NAME, SUBTITLE, SCHEMES, NOTIFICATIONS } from './constants';
import { processUserQuery } from './services/geminiService';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(AppState.IDLE);
  const [responseText, setResponseText] = useState<string>("నమస్కారం! నేను మీకు ఎలా సహాయం చేయగలను? (Hello! How can I help you today?)");
  const [activeScheme, setActiveScheme] = useState<SchemeData | null>(null);
  const [language, setLanguage] = useState<string>('te-IN');
  const [viewMode, setViewMode] = useState<'video' | 'audio'>('video');
  const [volume, setVolume] = useState<number>(0);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  
  // Speech Recognition Refs
  const recognitionRef = useRef<any>(null);
  const transcriptRef = useRef<string>("");

  // Refs for Speech Handling
  const utterancesRef = useRef<SpeechSynthesisUtterance[]>([]);
  const speechResumeIntervalRef = useRef<any>(null);
  const shouldSpeakRef = useRef<boolean>(false);
  
  const isProcessingRef = useRef<boolean>(false);
  const lastInteractionTimeRef = useRef<number>(0);

  const uiStrings = {
    'en-IN': { hearingYou: "Listening...", preparing: "Starting Mic...", placeholder: "Ask anything...", latest: "Latest Updates" },
    'hi-IN': { hearingYou: "सुन रहा हूँ...", preparing: "माइक शुरू हो रहा है...", placeholder: "कुछ भी पूछें...", latest: "नवीनतम अपडेट" },
    'te-IN': { hearingYou: "వింటున్నాను...", preparing: "మైక్ సిద్ధం అవుతోంది...", placeholder: "ఏదైనా అడగండి...", latest: "తాజా అప్‌డేట్‌లు" }
  };
  const strings = uiStrings[language as keyof typeof uiStrings] || uiStrings['en-IN'];

  useEffect(() => {
    const synth = window.speechSynthesis;
    const loadVoices = () => synth.getVoices();
    loadVoices();
    synth.onvoiceschanged = loadVoices;
    
    // Initialize Web Speech API for Local Transcript
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = language;
      
      recognitionRef.current.onresult = (event: any) => {
        let finalTrans = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            transcriptRef.current += event.results[i][0].transcript + " ";
          } else {
            finalTrans += event.results[i][0].transcript;
          }
        }
      };
    }

    // Cleanup on unmount
    return () => { 
      shouldSpeakRef.current = false;
      synth.cancel();
      if (speechResumeIntervalRef.current) clearInterval(speechResumeIntervalRef.current);
    };
  }, [language]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      const source = audioContextRef.current.createMediaStreamSource(stream);
      analyserRef.current = audioContextRef.current.createAnalyser();
      analyserRef.current.fftSize = 256;
      source.connect(analyserRef.current);
      
      const bufferLength = analyserRef.current.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);
      const updateVolume = () => {
        if (!analyserRef.current) return;
        analyserRef.current.getByteFrequencyData(dataArray);
        let sum = 0;
        for(let i=0; i<bufferLength; i++) sum += dataArray[i];
        setVolume(sum / bufferLength);
        animationFrameRef.current = requestAnimationFrame(updateVolume);
      };
      updateVolume();

      // Start Transcript Collection
      transcriptRef.current = "";
      if (recognitionRef.current) {
        recognitionRef.current.lang = language;
        try { recognitionRef.current.start(); } catch(e) { console.warn("Recognition start failed", e); }
      }

      // Start Audio Recording for API
      const mimeType = MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' : 'audio/ogg';
      const mediaRecorder = new MediaRecorder(stream, { mimeType });
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];
      mediaRecorder.ondataavailable = (e) => { if (e.data.size > 0) audioChunksRef.current.push(e.data); };
      mediaRecorder.onstop = async () => {
        // Stop Recognition
        if (recognitionRef.current) {
          try { recognitionRef.current.stop(); } catch(e) {}
        }

        const audioBlob = new Blob(audioChunksRef.current, { type: mimeType });
        const reader = new FileReader();
        reader.readAsDataURL(audioBlob);
        reader.onloadend = () => {
          const base64Audio = (reader.result as string).split(',')[1];
          // Pass BOTH audio and the local transcript
          handleAudioProcessing(base64Audio, transcriptRef.current);
        };
        stream.getTracks().forEach(track => track.stop());
        if (audioContextRef.current) { audioContextRef.current.close().catch(() => {}); audioContextRef.current = null; }
        if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
        setVolume(0);
      };
      mediaRecorder.start();
      setAppState(AppState.LISTENING);
    } catch (err) {
      setResponseText("Microphone access denied.");
      setAppState(AppState.IDLE);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === "recording") {
      mediaRecorderRef.current.stop();
    }
  };

  const handleMicInteraction = () => {
    const now = Date.now();
    if (now - lastInteractionTimeRef.current < 500) return;
    lastInteractionTimeRef.current = now;
    
    // Stop speaking if currently speaking
    if (appState === AppState.SPEAKING || appState === AppState.PLAYING_VIDEO) { 
      shouldSpeakRef.current = false; // Critical to stop loop
      window.speechSynthesis.cancel(); 
      utterancesRef.current = [];
      if (speechResumeIntervalRef.current) clearInterval(speechResumeIntervalRef.current);
      setAppState(AppState.IDLE); 
      setActiveScheme(null); 
      return; 
    }

    if (appState === AppState.IDLE) {
      setResponseText(strings.preparing); 
      window.speechSynthesis.cancel();
      startRecording();
    } else if (appState === AppState.LISTENING) { 
      stopRecording(); 
    }
  };

  const handleAudioProcessing = async (base64Audio: string, transcript: string) => {
    setAppState(AppState.PROCESSING);
    isProcessingRef.current = true;
    
    try {
      // Pass the transcript (if available) to the service
      const queryText = transcript && transcript.trim().length > 0 ? transcript : undefined;
      const result = await processUserQuery(queryText, base64Audio);
      
      let finalSpeechText = result.responseText;
      setResponseText(result.responseText);
      let targetLang = result.detectedLanguage || language;
      
      // Heuristic: If response has Telugu characters, force te-IN
      if (/[\u0C00-\u0C7F]/.test(finalSpeechText)) targetLang = 'te-IN';
      
      if (targetLang !== language) setLanguage(targetLang);

      if (result.relevantSchemeId) {
        const scheme = SCHEMES.find(s => s.id.toLowerCase() === result.relevantSchemeId?.toLowerCase());
        if (scheme) { 
          setActiveScheme(scheme); 
          setViewMode('video');
          setAppState(AppState.PLAYING_VIDEO); 
          finalSpeechText = constructSchemeNarration(scheme, targetLang, result.responseText);
        }
      }
      speakResponse(finalSpeechText, targetLang);
    } catch (e) {
      // Fallback in App layer (should rarely happen with new Service logic)
      setAppState(AppState.IDLE);
      isProcessingRef.current = false;
      setResponseText("Please try asking again.");
    }
  };

  const constructSchemeNarration = (scheme: SchemeData, lang: string, intro: string) => {
    let text = intro.trim();
    if (!text.match(/[.!?,]$/)) text += ".";
    text += " ";

    const labels: any = {
      'en-IN': { 
        ben: 'Benefits:', elig: 'Eligibility:', doc: 'Documents:', 
        step: 'Steps:', off: 'Office:', 
        sec: 'Legal Sections:', pen: 'Punishments and Fines:'
      },
      'hi-IN': { 
        ben: 'लाभ:', elig: 'पात्रता:', doc: 'दस्तावेज:', 
        step: 'चरण:', off: 'कार्यालय:',
        sec: 'कानूनी धाराएं:', pen: 'दंड और जुर्माना:'
      },
      'te-IN': { 
        ben: 'ప్రయోజనాలు:', elig: 'అర్హత:', doc: 'పత్రాలు:', 
        step: 'విధానం:', off: 'కార్యాలయం:',
        sec: 'చట్టపరమైన సెక్షన్లు:', pen: 'శిక్షలు మరియు జరిమానాలు:'
      }
    };
    const l = labels[lang] || labels['en-IN'];
    const suffix = lang === 'hi-IN' ? '_hi' : lang === 'te-IN' ? '_te' : '';
    
    const getLocalizedArr = (key: string, suf: string) => {
        const val = (scheme as any)[`${key}${suf}`] || (scheme as any)[key];
        return Array.isArray(val) ? val : [];
    };

    const ben = getLocalizedArr('benefits', suffix);
    const elig = getLocalizedArr('eligibility', suffix);
    const docs = getLocalizedArr('requiredDocuments', suffix);
    const steps = getLocalizedArr('applicationSteps', suffix);
    const sec = getLocalizedArr('legalSections', suffix);
    const pen = getLocalizedArr('penalties', suffix);
    const office = (scheme as any)[`relevantOffice${suffix}`] || (scheme as any).relevantOffice || '';

    // Helper to format list items as sentences
    const formatList = (arr: string[]) => arr.map(item => {
        const trimmed = item.trim();
        if (trimmed.length === 0) return "";
        return trimmed.endsWith('.') || trimmed.endsWith('?') || trimmed.endsWith('!') ? trimmed : trimmed + '.';
    }).filter(s => s.length > 0).join(' ');

    // Narrate everything
    if (sec.length > 0) text += `${l.sec} ${formatList(sec)} `;
    if (pen.length > 0) text += `${l.pen} ${formatList(pen)} `;
    if (ben.length > 0) text += `${l.ben} ${formatList(ben)} `;
    if (elig.length > 0) text += `${l.elig} ${formatList(elig)} `;
    if (docs.length > 0) text += `${l.doc} ${formatList(docs)} `;
    if (steps.length > 0) text += `${l.step} ${formatList(steps)} `;
    
    // Office info
    if (office) text += `${l.off} ${office}.`;
    
    return text;
  };

  const speakResponse = (text: string, lang: string) => {
    const synth = window.speechSynthesis;
    
    // 1. Reset State
    shouldSpeakRef.current = false;
    synth.cancel();
    utterancesRef.current = [];
    if (speechResumeIntervalRef.current) clearInterval(speechResumeIntervalRef.current);
    
    setTimeout(() => {
        shouldSpeakRef.current = true; 

        // 2. Preprocess Text for Better TTS
        let speakableText = text
            .replace(/₹/g, ' Rupees ')
            .replace(/\//g, ' or ')
            .replace(/\n/g, ' ')
            .replace(/\s+/g, ' '); 

        // 3. Chunking Logic
        const sentences = speakableText.match(/[^.!?]+[.!?]+/g) || [speakableText];
        
        if (sentences.length === 0) return;

        // 4. Voice Selection
        let allVoices = synth.getVoices();
        let selectedVoice = 
            allVoices.find(v => v.lang === lang && (v.name.includes('Google') || v.name.includes('Neural'))) ||
            allVoices.find(v => v.lang === lang) ||
            allVoices.find(v => v.lang.startsWith(lang.split('-')[0]));
        
        if (!selectedVoice && lang.startsWith('te')) {
            selectedVoice = allVoices.find(v => v.lang.includes('te'));
        }
        if (!selectedVoice && lang.startsWith('hi')) {
            selectedVoice = allVoices.find(v => v.lang.includes('hi'));
        }

        let currentIndex = 0;

        const playNextChunk = () => {
            if (!shouldSpeakRef.current) return;

            if (currentIndex >= sentences.length) {
                setAppState(prev => prev === AppState.PLAYING_VIDEO ? AppState.PLAYING_VIDEO : AppState.IDLE);
                isProcessingRef.current = false;
                if (speechResumeIntervalRef.current) clearInterval(speechResumeIntervalRef.current);
                return;
            }

            const chunkText = sentences[currentIndex].trim();
            if (chunkText.length < 2) {
                currentIndex++;
                playNextChunk();
                return;
            }

            const utterance = new SpeechSynthesisUtterance(chunkText);
            utterance.lang = lang;
            if (selectedVoice) utterance.voice = selectedVoice;
            utterance.rate = 0.95;
            utterance.volume = 1.0;

            utterancesRef.current.push(utterance);

            utterance.onstart = () => {
                 if (currentIndex === 0 && shouldSpeakRef.current) {
                     setAppState(prev => prev === AppState.PLAYING_VIDEO ? AppState.PLAYING_VIDEO : AppState.SPEAKING);
                 }
            };

            const handleNext = () => {
                const index = utterancesRef.current.indexOf(utterance);
                if (index > -1) utterancesRef.current.splice(index, 1);
                
                currentIndex++;
                if (shouldSpeakRef.current) {
                  setTimeout(playNextChunk, 50); 
                }
            };

            utterance.onend = handleNext;
            utterance.onerror = (e) => {
                if (e.error !== 'interrupted' && e.error !== 'canceled') {
                    console.warn("TTS Error:", e);
                }
                handleNext();
            };

            try {
              synth.speak(utterance);
            } catch (err) {
              handleNext();
            }
        };

        if (speechResumeIntervalRef.current) clearInterval(speechResumeIntervalRef.current);
        speechResumeIntervalRef.current = setInterval(() => {
            if (synth.speaking && synth.paused) {
                synth.resume();
            }
        }, 2000);

        playNextChunk();
    }, 100);
  };

  return (
    <div className={`min-h-screen flex flex-col bg-slate-900 text-white relative overflow-hidden font-inter ${language.startsWith('te') ? 'font-telugu' : ''}`}>
      <div className="bg-blue-900/40 border-b border-blue-800/50 h-10 flex items-center overflow-hidden z-[40] relative">
        <div className="px-4 bg-blue-600 text-xs font-black uppercase tracking-tighter h-full flex items-center shrink-0 shadow-lg relative z-[50]">
          {strings.latest}
        </div>
        <div className="flex-1 whitespace-nowrap overflow-hidden">
          <div className="inline-block animate-marquee whitespace-nowrap py-1">
            {NOTIFICATIONS.map((note, idx) => (
              <span key={idx} className="mx-10 text-sm font-bold text-blue-100">
                <span className="text-blue-500 mr-2">✦</span> {note}
              </span>
            ))}
          </div>
        </div>
      </div>

      <header className="pt-12 pb-6 px-6 text-center z-10 shrink-0">
        <div className="flex flex-col items-center">
          <div className="mb-4 p-3 bg-slate-800/80 rounded-2xl border border-slate-700 shadow-xl flex items-center gap-5 backdrop-blur-sm">
             <img src="https://upload.wikimedia.org/wikipedia/commons/5/55/Emblem_of_India.svg" alt="India Emblem" className="h-16 w-auto brightness-0 invert opacity-95" />
             <div className="h-10 w-px bg-slate-600/50"></div>
             <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/f7/Government_of_Telangana_Logo.png/600px-Government_of_Telangana_Logo.png" alt="Telangana Emblem" className="h-16 w-auto object-contain" />
          </div>
          <h1 className="text-3xl md:text-4xl font-black tracking-tight text-white mb-2 uppercase drop-shadow-lg">{APP_NAME}</h1>
          <p className="text-blue-400 font-bold uppercase tracking-[0.2em] text-xs">{SUBTITLE}</p>
        </div>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center px-6 max-w-4xl mx-auto w-full z-10 space-y-8 md:space-y-12">
        <div className="w-full relative">
          <div className="bg-slate-800/60 backdrop-blur-xl p-8 rounded-[40px] border border-slate-700/50 shadow-2xl min-h-[160px] flex flex-col items-center justify-center text-center transition-all duration-500">
            {appState === AppState.LISTENING ? (
              <div className="space-y-3">
                 <div className="flex gap-2 justify-center mb-4 h-8 items-end">
                   {[...Array(8)].map((_, i) => (
                     <div key={i} className="w-1.5 bg-blue-500 rounded-full transition-all duration-75" 
                       style={{ height: `${Math.max(15, volume * (0.5 + Math.random()))}%`, opacity: 0.5 + (volume/255) }}
                     />
                   ))}
                 </div>
                 <p className="text-2xl text-blue-300 font-bold">{strings.hearingYou}</p>
                 <p className="text-sm text-slate-400 uppercase tracking-widest font-black">Tap Button to Stop</p>
              </div>
            ) : (
              <div className="animate-in fade-in slide-in-from-bottom-2 duration-700">
                <p className={`text-2xl md:text-3xl font-bold leading-tight ${language.startsWith('te') ? 'font-telugu' : ''} ${appState === AppState.SPEAKING || appState === AppState.PLAYING_VIDEO ? 'text-blue-300' : 'text-slate-100'}`}>
                   {responseText}
                </p>
              </div>
            )}
          </div>
        </div>

        <div className="flex flex-col items-center gap-8 md:gap-12">
          <MicButton appState={appState} onClick={handleMicInteraction} language={language} />
          <div className="space-y-6 flex flex-col items-center">
            <div className="flex flex-wrap justify-center gap-3">
              {[
                { code: 'en-IN', label: 'English' },
                { code: 'hi-IN', label: 'हिन्दी' },
                { code: 'te-IN', label: 'తెలుగు' }
              ].map((lang) => (
                <button 
                  key={lang.code} 
                  onClick={() => { 
                    shouldSpeakRef.current = false;
                    window.speechSynthesis.cancel();
                    setLanguage(lang.code); 
                    setResponseText(lang.code === 'te-IN' ? "నమస్కారం! నేను మీకు ఎలా సహాయం చేయగలను?" : lang.code === 'hi-IN' ? "नमस्ते! मैं आपकी क्या सहायता कर सकता हूँ?" : "Hello! How can I help you today?");
                    setAppState(AppState.IDLE);
                  }} 
                  className={`px-6 py-2.5 rounded-2xl text-sm font-black border transition-all duration-300 transform hover:scale-105 ${language === lang.code ? 'bg-blue-600 border-blue-400 text-white shadow-xl shadow-blue-600/20' : 'bg-slate-800/40 border-slate-700 text-slate-400'}`}
                >
                  {lang.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </main>

      <footer className="p-8 text-center shrink-0 z-10">
      </footer>

      {viewMode === 'video' ? (
        <VideoOverlay 
          scheme={activeScheme} 
          onClose={() => { shouldSpeakRef.current = false; window.speechSynthesis.cancel(); setActiveScheme(null); setAppState(AppState.IDLE); }} 
          language={language} 
          onSwitchToAudio={() => setViewMode('audio')} 
          onNarrate={(text) => speakResponse(text, language)}
        />
      ) : (
        <AudioOverlay 
          scheme={activeScheme} 
          onClose={() => { shouldSpeakRef.current = false; window.speechSynthesis.cancel(); setActiveScheme(null); setAppState(AppState.IDLE); }} 
          language={language} 
          onSwitchToVideo={() => setViewMode('video')} 
          onNarrate={(text) => speakResponse(text, language)}
        />
      )}

      <style>{`
        @keyframes marquee { 0% { transform: translateX(100vw); } 100% { transform: translateX(-100%); } }
        .animate-marquee { animation: marquee 35s linear infinite; }
      `}</style>
    </div>
  );
};

export default App;
